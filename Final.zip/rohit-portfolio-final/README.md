# Rohit Y — Portfolio

An image-led personal portfolio built with **plain HTML, CSS and JavaScript** (no frameworks, no build step, no dependencies except Google Fonts).

On a laptop or desktop it plays as **six full-screen scenes** joined by a circular wipe instead of one long scroll, under a floating **frosted-glass header** (iOS style). On phones, tablets and small windows it becomes a normal scrolling page with the same colours and content.

> Status: built and tested locally. **Not deployed yet** — follow section 9 to publish.

---

## 1. Run it

1. **Extract the whole zip first** (don't open files from inside the zip).
2. Open the folder in VS Code, install the **Live Server** extension, right-click `index.html` → **Open with Live Server**.

Keep `index.html`, `css/`, `js/` and `assets/` together — the page needs all of them.

## 2. Project structure

```text
rohit-portfolio/
├── index.html        ← the six scenes (structure + fixed text)
├── css/style.css     ← colours, fonts, layouts, animations
├── js/
│   ├── data.js       ← YOUR CONTENT: links, projects, timeline, skills, image paths
│   └── script.js     ← scene engine, project browser, cursor, form
├── assets/
│   ├── images/       ← project artwork, your portrait, favicon
│   ├── videos/       ← optional
│   └── resume/       ← your PDF résumé
├── README.md
└── .gitignore
```

**Rule of thumb:** what the site *says* → `data.js` (and About/Home text in `index.html`); how it *looks* → `style.css`; how it *behaves* → `script.js`.

## 3. Add YOUR photo (important)

The home scene has a large circular portrait. Until you add a photo it shows a monogram "R".

1. Save a square-ish photo as `assets/images/rohit.jpg` (about 800×800 px, face centred).
2. Refresh. It appears in black-and-white with a royal-blue tint and turns to full colour when hovered.

## 4. About the images

- `jard.jpg`, `skill-tracker.jpg`, `about.jpg`, `terminal.jpg`, `skills.jpg` are **original code-editor illustrations made for this site**. They are artwork, not screenshots of your real code. The JARD one illustrates the pipeline described in the repo README; the Skill Tracker one uses its real XP-per-level (150) and rank names.
- To use a real screenshot instead, save it in `assets/images/` (square crops look best in the circles) and change `image:` for that project in `data.js`.
- Prefer photos you own or that are free to use commercially (e.g. Unsplash, Pexels) and keep files under ~300 KB.

## 5. How the scenes work

- Each `<section class="scene">` is one screen. On large windows JavaScript adds `deck-on` to `<html>`; CSS then stacks every scene fixed on top of each other, all hidden.
- Moving to a scene reveals it with `clip-path: circle(...)`, a growing circle. Nav clicks start the circle at your click; scrolling down starts it from the bottom, up from the top.
- Controls: mouse wheel, ↑ ↓ / PageUp / PageDown / Home / End, swipe, and the nav links. A small "Scroll to explore" hint at the right edge disappears after your first move. There are no on-screen counters or arrows.
- **The last scene (Contact) scrolls a little further** to reveal the footer: site note, links, © line and a **Back to top** button that wipes you back to Home. Scrolling up returns to the top of Contact first, and only then to the previous scene.
- Sideways scrolling on the timeline uses drag, the arrow buttons beside the heading, or Shift + wheel.
- **Projects:** click a name in the list to switch projects (hovering does nothing, so you can move the mouse freely to the buttons). Arrow keys also switch when a project name has focus. Click the big circle for the case study.
- **Cursor:** a ring follows smoothly, and a small dot sits exactly on the pointer so you always see where you click.
- **Glass header:** `.nav` in `css/style.css` uses `backdrop-filter: blur()`; its tint switches between light and dark to match the scene beneath it (`html[data-tone]`).
- Headlines are split into words/letters that rise from behind a mask when the scene activates (`data-split`). Other elements with `data-in` fade up; `--d` sets the delay.
- Screens narrower than 900 px or shorter than 640 px, and users with "reduce motion" on, get the normal scrolling layout automatically.

## 6. Colours, fonts, spacing

Edit the tokens at the top of `css/style.css`:

```css
--ink:   #080b1f;  /* dark scenes */
--paper: #eee8db;  /* light scenes */
--royal: #1f35d1;  /* blue scenes */
```

Each scene picks its colours in the `.scene--home / --about …` rules. Fonts: `--serif`, `--sans`, `--mono` (and update the Google Fonts `<link>`).

## 7. Update your content (`js/data.js`)

| I want to… | Edit |
|---|---|
| Add a project | copy an object in `projects` (set `short`, `image`, `repo` …) — it appears in the big project list automatically |
| Add a real live demo | set `live: "https://…"` |
| Add timeline / experience | `timeline` |
| Add a verified award | `achievements` (+ optional `proof` link) |
| Move Learning → Skills | `skills` |
| GitHub / LinkedIn / LeetCode / HackerRank, email, résumé, contact form | `links` |
| Change Home / About wording | `index.html` |
| Add a new scene | copy a `<section class="scene">`, add a nav link, add a `.scene--name` colour rule |

## 8. Contact form

It is **not connected to a server** and says so if submitted. To make it send: create a free form at formspree.io and paste its URL into `links.formEndpoint`. If only `links.email` is set, it opens the visitor's email app instead. Never commit secret API keys.

## 9. Git and GitHub Pages

```bash
git init
git add .
git commit -m "Initial portfolio"
git branch -M main
git remote add origin https://github.com/rohityadav-RY/rohit-portfolio.git
git push -u origin main
```
Then on GitHub: **Settings → Pages → Deploy from a branch → `main` / root → Save**. The site appears at `https://rohityadav-ry.github.io/rohit-portfolio/` after a few minutes.

To update later: `git add .` → `git commit -m "what changed"` → `git push`.

## 10. Testing checklist

- [ ] Open DevTools (`F12`) → Console shows no red errors (a missing `rohit.jpg` is expected until you add it)
- [ ] Wheel, arrow keys and nav links all change scenes; the URL hash follows; the header stays readable on every scene
- [ ] Hover the second project in the list; click the big circle → case-study panel opens, `Esc` closes it
- [ ] Timeline drags / arrow buttons scroll it
- [ ] Resize below 900 px wide → normal scrolling layout, **Menu** button works
- [ ] Tab through the page (visible outline on every link/button)
- [ ] DevTools → Rendering → emulate "prefers-reduced-motion: reduce" → no animations
- [ ] Both **View Repository** buttons and the JARD demo video link open correctly
- [ ] Click your **LeetCode** and **HackerRank** buttons once yourself (HackerRank could not be checked automatically when this was built)
- [ ] Scroll to the end of Contact: footer, © line and **Back to top** all work
- [ ] Achievement wording matches what you can prove (add a `proof` link)

## 11. Content notes

- JARD and Skill Tracker text comes from each repo's README and, for Skill Tracker, from running the app (XP, daily log, streak, ranks Rookie → Elite).
- The **Second prize** (Exasol AI Build Challenge 2026, team) comes from your own statement; the repo README doesn't mention it. Add proof when you have it.
- LeetCode: `leetcode.com/u/rohityadav_ry` was confirmed to exist. HackerRank: `hackerrank.com/profile/rohityadav_forai` is your URL exactly as given. No live stats are shown, because they change.
- The JARD "My part" paragraph says you built the frontend — edit if not exact.
